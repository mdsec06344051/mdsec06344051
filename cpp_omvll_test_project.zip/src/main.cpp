#include <iostream>
#include <string>
#include <vector>

static std::string decode(const std::string& in, unsigned char k) {
    std::string out = in;
    for (auto &c : out) c ^= k;
    return out;
}

int main() {
    std::string s_plain = "TopSecretKey-DoNotShipPlain";    // ORIGINAL string
    std::string s_obf   = decode(std::string(":6*5(%6*'6&2/6,;N"), 0x17); // "TopSecretKey-DoNotShipPlain" XORed with 0x17
    std::cout << "Original string len: " << s_plain.size() << "\n";
    std::cout << "Decoded string len : " << s_obf.size()   << "\n";
    return 0;
}
