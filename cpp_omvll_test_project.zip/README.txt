C++ OMVLL/OLLVM Test Project
============================
- Build original (no obfuscation):
    mkdir build && cd build
    cmake -DCMAKE_BUILD_TYPE=Release -DOBF_ENABLE=OFF ..
    cmake --build . -j

- Build obfuscated (with OLLVM-like flags):
    mkdir build-obf && cd build-obf
    cmake -DCMAKE_BUILD_TYPE=Release -DOBF_ENABLE=ON ..
    cmake --build . -j

- Optional: strip release binary
    strip --strip-unneeded myapp

Flags applied when OBF_ENABLE=ON:
  -O2 -fPIC -fvisibility=hidden -ffunction-sections -fdata-sections -fPIE
  -mllvm -fla -mllvm -bcf -mllvm -sub -mllvm -split -mllvm -bcf_prob=75
  Linker: -Wl,--gc-sections -Wl,-z,relro -Wl,-z,now -Wl,-z,noexecstack -pie
